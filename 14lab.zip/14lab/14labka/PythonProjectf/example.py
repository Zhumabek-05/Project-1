from student_utils import add, median, reverse_string
from student_utils import prefix_message, timestamp_message
print(add(3, 3))
print(median([1, 3, 5, 7]))
print(reverse_string("kebamuhZ"))
print(prefix_message("Not Have"))
print(timestamp_message("Date"))
