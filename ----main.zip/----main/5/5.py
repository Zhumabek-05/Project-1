# Оқушылардың бойлары (мысал үшін)
heights = [175, 178, 180, 185, 170, 175, 185]

# Ең үлкен бойды табамыз
max_height = max(heights)

# Сол бойдағы оқушылар санын табамыз
count = heights.count(max_height)

print("Ең үлкен бой:", max_height)
print("Сол бойдағы оқушылар саны:", count)