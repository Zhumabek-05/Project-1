a = 10
b = 3

print(a - b)  # азайту
print(a + b)  # косу
print(a * b)  # кобейту
print(a ** b) # дареже
print(a / b)  # болу
print(a // b) # бутын санд болу
print(a % b)  # остаток

print()
